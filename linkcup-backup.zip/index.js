import { PaperPlane } from './paperplane.js';
import { initializeAudio, handleAudio, resetAudioState } from './audioManager.js';
import { handleMessages, resetMessageState } from './messageManager.js';
import { initUI, updateUI, resetUI, resizeChart } from './uiManager.js';

const extensionName = "linkcup";
const extensionFolderPath = `scripts/extensions/third-party/${extensionName}`;

// Global state variables
let linkCUPDevice = null;
let writeCharacteristic = null;
let notifyCharacteristic = null;
let paperPlane = null;
let handshakeState = {
    uuid_acked: false,
    mac_acked: false,
    firmware_acked: false,
};

// Constants for Bluetooth communication
const LCU_SERVICE_UUID = "6e400001-b5a3-f393-e0a9-e50e24dcca9e";
const LCU_WRITE_CHARACTERISTIC_UUID = "6e400002-b5a3-f393-e0a9-e50e24dcca9e";
const LCU_NOTIFY_CHARACTERISTIC_UUID = "6e400003-b5a3-f393-e0a9-e50e24dcca9e";

// UI Elements
const getDOM = () => {
    const status = document.getElementById(`linkcup-status`);
    const connectBtn = document.getElementById(`linkcup-connect-btn`);
    const dataContainer = document.getElementById(`linkcup-data-container`);
    return { status, connectBtn, dataContainer };
};

// Function to handle the special key event
const handleKeyEvent = (values) => {
    const context = SillyTavern.getContext();
    // Key event messaging can be complex, so it stays here for now.
    // It could be moved to messageManager if it grows.
    resetMessageState(); // Reset any pending reports

    const zhClimax = values.v > 0 ? '而且是内射！' : '他射在了外面！';
    const enClimax = values.v > 0 ? 'and came inside!' : 'and came outside!';
    const zhMessage = `{{user}}：“射精了！” (${zhClimax})`;
    const enMessage = `{{user}}: "I'm cumming!" (${enClimax})`;
    
    const finalMessage = `${zhMessage}\n${enMessage}`;

    console.log("linkCUP key event message:", finalMessage);

    const message = { mes: finalMessage, is_user: true, is_system: false, name: '{{user}}', send_date: Date.now(), is_api: false };
    context.chat.push(message);
    if (paperPlane) paperPlane.resetIntensityScore();

    context.generate();
    toastr.success("特殊事件已发送！", "linkCUP");
};

// Function to send data to the device
const sendToDevice = async (data) => {
    if (!writeCharacteristic) {
        console.error("Write characteristic not available.");
        toastr.error("linkCUP: Write characteristic not available.", "Connection Error");
        return;
    }
    try {
        const encoder = new TextEncoder();
        await writeCharacteristic.writeValue(encoder.encode(JSON.stringify(data)));
        console.log("Sent:", data);
    } catch (error) {
        console.error("Error writing to device:", error);
        toastr.error("linkCUP: Failed to send data to device.", "Connection Error");
    }
};

// Handle incoming data notifications from the device
const handleNotifications = (event) => {
    const value = event.target.value;
    const decoder = new TextDecoder('utf-8');
    const jsonString = decoder.decode(value);

    try {
        const data = JSON.parse(jsonString);
        const { status } = getDOM();

        switch (data.type) {
            case 1:
                if (!handshakeState.uuid_acked) {
                    sendToDevice({ "type": 2, "ack": 1 });
                    handshakeState.uuid_acked = true;
                }
                break;
            case 4:
                if (!handshakeState.mac_acked) {
                    sendToDevice({ "type": 2, "ack": 2 });
                    handshakeState.mac_acked = true;
                }
                break;
            case 5:
                if (!handshakeState.firmware_acked) {
                    sendToDevice({ "type": 2, "ack": 3 });
                    handshakeState.firmware_acked = true;
                    status.textContent = "Connected";
                    toastr.success("linkCUP Connected", "Success");
                }
                break;
            case 7:
            case 14:
                if (handshakeState.firmware_acked) {
                    const valueData = data.value || data;
                    const v_value = Array.isArray(valueData.v) ? valueData.v[0] : valueData.v;
                    const realtimeData = {
                        v: v_value, p: valueData.p,
                        Yaw: Math.round(valueData.Yaw / 100),
                        Pitch: Math.round(valueData.Pitch / 100),
                        Roll: Math.round(valueData.Roll / 100),
                    };
                    if (paperPlane) paperPlane.update(realtimeData);
                }
                break;
            case 11:
                if (handshakeState.firmware_acked && paperPlane && data.k === 1) {
                    paperPlane.updateKeyEvent();
                }
                break;
        }
    } catch (error) {
        console.error("Failed to parse notification JSON:", error, "Raw data:", jsonString);
    }
};

// Main connection function
const onConnectClick = async () => {
    const { status, connectBtn } = getDOM();

    if (!navigator.bluetooth) {
        toastr.error("Web Bluetooth is not available on this browser.", "Compatibility Error");
        status.textContent = "Bluetooth not supported.";
        return;
    }

    if (linkCUPDevice && linkCUPDevice.gatt.connected) {
        linkCUPDevice.gatt.disconnect();
        return;
    }

    try {
        status.textContent = "Requesting device...";
        toastr.info("Please select your linkCUP from the list.", "Bluetooth");

        linkCUPDevice = await navigator.bluetooth.requestDevice({
            acceptAllDevices: true,
            optionalServices: [LCU_SERVICE_UUID]
        });

        linkCUPDevice.addEventListener('gattserverdisconnected', onDisconnected);
        status.textContent = "Connecting to GATT server...";
        const server = await linkCUPDevice.gatt.connect();

        // Unlock audio context by playing a silent sound right after user interaction
        unlockAudioContext();

        status.textContent = "Getting service...";
        const service = await server.getPrimaryService(LCU_SERVICE_UUID);
        status.textContent = "Getting characteristics...";
        writeCharacteristic = await service.getCharacteristic(LCU_WRITE_CHARACTERISTIC_UUID);
        notifyCharacteristic = await service.getCharacteristic(LCU_NOTIFY_CHARACTERISTIC_UUID);
        status.textContent = "Starting notifications...";
        await notifyCharacteristic.startNotifications();
        notifyCharacteristic.addEventListener('characteristicvaluechanged', handleNotifications);

        status.textContent = "Connected. Waiting for handshake...";
        connectBtn.textContent = "Disconnect";

        paperPlane = new PaperPlane((values, eventType = 'realtime') => {
            // The new, clean delegation model
            updateUI(values);
            if (eventType === 'keyEvent') {
                handleKeyEvent(values);
            } else {
                handleAudio(values);
                handleMessages(values, paperPlane);
            }
        });
        
        // Initialize all modules
        initializeAudio();
        initUI();

    } catch (error) {
        console.error("Bluetooth connection failed:", error);
        status.textContent = `Error: ${error.message}`;
        toastr.error(`Connection failed: ${error.message}`, "Bluetooth Error");
        onDisconnected();
    }
};

const onDisconnected = () => {
    const { status, connectBtn } = getDOM();
    status.textContent = "Disconnected";
    connectBtn.textContent = "Connect linkCUP";

    // Reset all modules
    resetUI();
    resetAudioState();
    resetMessageState();

    linkCUPDevice = null;
    writeCharacteristic = null;
    notifyCharacteristic = null;

    if (paperPlane) {
        paperPlane.destroy();
        paperPlane = null;
    }
    handshakeState = { uuid_acked: false, mac_acked: false, firmware_acked: false };
    toastr.warning("linkCUP has been disconnected.", "Connection Lost");
};

// This function is called when the extension is loaded
jQuery(async () => {
    const floatingWindow = $(`
        <div id="linkcup-floating-window" class="linkcup-floating-window">
            <div id="linkcup-drag-handle" class="linkcup-drag-handle">
                <span>linkCUP Control</span>
                <button id="linkcup-close-btn" class="linkcup-close-btn">X</button>
            </div>
            <div id="linkcup-content-wrapper"></div>
        </div>
    `);
    $('body').append(floatingWindow);

    const settingsHtml = await $.get(`${extensionFolderPath}/public/linkcup.html`);
    $("#linkcup-content-wrapper").html(settingsHtml);

    // Wait for SillyTavern to be ready before setting up event listeners
    const context = SillyTavern.getContext();
    context.eventSource.on(context.event_types.APP_READY, () => {
        console.log("linkCUP: SillyTavern is ready. Initializing.");
        $("#linkcup-connect-btn").on("click", onConnectClick);
        $("#linkcup-close-btn").on("click", () => floatingWindow.hide());
    });

    let offsetX, offsetY;
    const dragHandle = document.getElementById('linkcup-drag-handle');
    const windowEl = document.getElementById('linkcup-floating-window');
    const move = (e) => {
        windowEl.style.left = `${e.clientX - offsetX}px`;
        windowEl.style.top = `${e.clientY - offsetY}px`;
    };
    dragHandle.addEventListener('mousedown', (e) => {
        offsetX = e.clientX - windowEl.offsetLeft;
        offsetY = e.clientY - windowEl.offsetTop;
        document.addEventListener('mousemove', move);
    });
    document.addEventListener('mouseup', () => {
        document.removeEventListener('mousemove', move);
    });

    const openButtonHtml = `<button id="open-linkcup-window-btn" class="menu_button">Open linkCUP Window</button>`;
    $("#extensions_settings").append(openButtonHtml);
    $("#open-linkcup-window-btn").on("click", () => {
        floatingWindow.show();
        resizeChart();
    });
});

// Function to play a silent sound to unlock the AudioContext.
// This is required by modern browsers to allow audio playback initiated by scripts.
function unlockAudioContext() {
    const silentWav = "data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA";
    const audio = new Audio(silentWav);
    audio.volume = 0;
    audio.play().catch(e => console.warn("Could not unlock audio context:", e));
    console.log("Attempting to unlock audio context.");
}
