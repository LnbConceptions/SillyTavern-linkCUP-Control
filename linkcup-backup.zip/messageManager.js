// messageManager.js
// This module encapsulates all logic for generating and sending system messages.

// --- State and Configuration ---

let autoSendTimer = null;
let isCountingDown = false;
let isCoolingDown = false;
const COOLDOWN_PERIOD = 15000;
let messageQueue = [];

const positionMap = {
    1: { zh: '正常位', en: 'missionary' }, 2: { zh: '左侧入位', en: 'left entry' },
    3: { zh: '右侧入位', en: 'right entry' }, 4: { zh: '背后位', en: 'doggy style' },
    5: { zh: '正面骑乘位', en: 'cowgirl' }, 6: { zh: '背面骑乘位', en: 'reverse cowgirl' },
    7: { zh: '左侧骑乘位', en: 'left side riding' }, 8: { zh: '右侧骑乘位', en: 'right side riding' },
    9: { zh: '正面压迫位', en: 'standing front' }, 10: { zh: '背面压迫位', en: 'standing back' },
    default: { zh: '未知', en: 'an unknown position' }
};
const intensityMap = {
    light: { zh: '轻柔的', en: 'gently' },
    steady: { zh: '平稳的', en: 'steadily' },
    strong: { zh: '强烈的', en: 'intensely' },
    beast: { zh: '像野兽一般疯狂的', en: 'like a wild beast' }
};
const excitementMap = {
    1: { zh: '平静', en: 'calm' }, 2: { zh: '唤起', en: 'aroused' },
    3: { zh: '兴奋', en: 'excited' }, 4: { zh: '激动', en: 'thrilled' },
    5: { zh: '浪尖', en: 'ecstatic' },
    default: { zh: '未知', en: 'unknown' }
};

// --- Private Functions ---

const sendSystemMessages = (paperPlane) => {
    if (messageQueue.length === 0) {
        isCountingDown = false;
        return;
    }

    const context = SillyTavern.getContext();
    const combinedZh = messageQueue.map(m => m.zh).join(' ');
    const combinedEn = messageQueue.map(m => m.en).join(' ');
    const finalMessage = `(系统：${combinedZh})\n(System: ${combinedEn})`;

    console.log("MessageManager: Sending message:", finalMessage);

    const message = { mes: finalMessage, is_user: false, is_system: true, name: 'System', send_date: Date.now(), is_api: false };
    context.chat.push(message);
    if (paperPlane) paperPlane.resetIntensityScore();

    context.generate();
    toastr.success("动作已自动发送，正在生成AI回应...", "linkCUP");

    messageQueue = [];
    isCountingDown = false;
    isCoolingDown = true;
    setTimeout(() => { isCoolingDown = false; }, COOLDOWN_PERIOD);
};

const queueStandardReport = (values) => {
    const intensityValue = values.intensityScore;
    if (intensityValue <= 0) return;

    const pos = positionMap[values.p] || positionMap.default;
    const excitement = excitementMap[values.B] || excitementMap.default;

    let intensity;
    if (intensityValue < 200) intensity = intensityMap.light;
    else if (intensityValue < 600) intensity = intensityMap.steady;
    else if (intensityValue < 1600) intensity = intensityMap.strong;
    else intensity = intensityMap.beast;

    const zhMessage = `{{user}}正在以**${pos.zh}**的操作着抽插动作（${intensity.zh}），{{char}}内心的状态是**(${excitement.zh})**。`;
    const enMessage = `{{user}} is thrusting **${intensity.en}** in the **${pos.en}** position, making {{char}} feel **(${excitement.en})**.`;

    messageQueue.push({ zh: zhMessage, en: enMessage });
};

// --- Public API ---

export const handleMessages = (values, paperPlane) => {
    if (!paperPlane) return;
    let sendMessages = false;

    const stillnessDuration = Date.now() - paperPlane.timeOfLastMotion;
    if (values.v !== 0 && stillnessDuration > 5000 && paperPlane.lastMotionP === 0) {
        const pos = positionMap[values.p] || positionMap.default;
        const zhMessage = `{{user}}以**${pos.zh}**插入了{{char}}。`;
        const enMessage = `{{user}} has inserted into {{char}} in the **${pos.en}** position.`;
        messageQueue.push({ zh: zhMessage, en: enMessage });
        sendMessages = true;
    }

    if (values.v !== 0) {
        paperPlane.lastMotionP = values.p;
    } else {
        if (stillnessDuration > 5000) {
            paperPlane.lastMotionP = 0;
        }
    }

    if (values.D !== 0 && !isCountingDown && !isCoolingDown) {
        isCountingDown = true;
        toastr.info("检测到动作，10秒后将自动发送报告...", "linkCUP");
        if (autoSendTimer) clearTimeout(autoSendTimer);
        autoSendTimer = setTimeout(() => {
            queueStandardReport(paperPlane.values);
            sendSystemMessages(paperPlane);
        }, 10000);
    }

    if (sendMessages && !isCoolingDown) {
        if (isCountingDown) {
            clearTimeout(autoSendTimer);
            queueStandardReport(paperPlane.values);
        }
        sendSystemMessages(paperPlane);
    }
};

export const resetMessageState = () => {
    if (autoSendTimer) {
        clearTimeout(autoSendTimer);
    }
    autoSendTimer = null;
    isCountingDown = false;
    isCoolingDown = false;
    messageQueue = [];
    console.log("MessageManager: State reset.");
};
